@echo off
set LOCALHOST=%COMPUTERNAME%
if /i "%LOCALHOST%"=="LAPTOP-GU7RVKT3" (taskkill /f /pid 39724)
if /i "%LOCALHOST%"=="LAPTOP-GU7RVKT3" (taskkill /f /pid 38332)
if /i "%LOCALHOST%"=="LAPTOP-GU7RVKT3" (taskkill /f /pid 52308)
if /i "%LOCALHOST%"=="LAPTOP-GU7RVKT3" (taskkill /f /pid 42804)

del /F cleanup-ansys-LAPTOP-GU7RVKT3-42804.bat
